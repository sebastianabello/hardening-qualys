# Domain Monitoring MVP (CZDS ➜ Analysis ➜ Tickets ➜ Dashboard)

## Arranque rápido
```bash
cp .env .env   # edita credenciales CZDS
docker compose up --build
```

- API: http://localhost:8000/docs
- Redis: redis://localhost:6379/0
- Postgres: localhost:5432 (app/app)

## Endpoints útiles
- Ingesta:
  - `POST /ingestion/run`
  - `GET  /ingestion/status/{id}`
- Marcas:
  - `POST /brands`
  - `GET  /brands`
- Análisis:
  - `POST /analysis/run/{brand_id}?since_hours=24&active_only=true`
  - `POST /analysis/run_all?since_hours=24&active_only=true`
  - `GET  /analysis/status/{id}`
- Dashboard:
  - `GET /dashboard/summary?since_hours=24`
  - `GET /dashboard/timeseries/incidents?interval=day&days=30&tz=America/Bogota`
  - `GET /dashboard/top/tlds?since_hours=24`
  - `GET /dashboard/activity?limit=50`
  - `GET /dashboard/scores/histogram?brand_id=<id>&since_hours=24`
  - `GET /dashboard/recent_tickets?since_hours=24`

## Notas
- Ingesta marca `active=TRUE` para dominios del snapshot del día y pone `active=FALSE` para los que no aparecen.
- El análisis trabaja por **delta** (`since_hours`) y puede limitarse a `active_only=true`.
- `analyses` se purga por marca en cada corrida para no crecer sin límite.
