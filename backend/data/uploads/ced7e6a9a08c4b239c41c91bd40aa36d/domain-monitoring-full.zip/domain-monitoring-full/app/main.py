from fastapi import FastAPI
from .db import Base, engine
from .routers import ingestion, brands, analysis, dashboard, tickets, domains
from fastapi.middleware.cors import CORSMiddleware

Base.metadata.create_all(bind=engine)

app = FastAPI(title="Domain Monitoring API")
app.include_router(ingestion.router)
app.include_router(brands.router)
app.include_router(analysis.router)
app.include_router(dashboard.router)
app.include_router(tickets.router)
app.include_router(domains.router)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/health")
def health():
    return {"ok": True}
