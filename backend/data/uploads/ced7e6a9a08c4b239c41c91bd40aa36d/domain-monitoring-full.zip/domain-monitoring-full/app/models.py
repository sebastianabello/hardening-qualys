import uuid
from sqlalchemy.dialects.postgresql import UUID, JSONB
from sqlalchemy import Column, String, Boolean, Integer, BigInteger, ForeignKey, UniqueConstraint, TIMESTAMP, Float, Enum, func
from sqlalchemy.orm import mapped_column
from .db import Base

class Zone(Base):
    __tablename__ = "zones"
    id = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    tld = mapped_column(String, nullable=False, index=True)
    collected_at = mapped_column(TIMESTAMP(timezone=True), server_default=func.now(), nullable=False)
    file_name = mapped_column(String, nullable=False)
    bytes = mapped_column(BigInteger, nullable=False)
    sha256 = mapped_column(String, nullable=False, index=True)

class Domain(Base):
    __tablename__ = "domains"
    id = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    tld = mapped_column(String, nullable=False, index=True)
    fqdn = mapped_column(String, nullable=False)
    sld = mapped_column(String, nullable=False)
    label_no_tld = mapped_column(String, nullable=False, index=True)
    first_seen = mapped_column(TIMESTAMP(timezone=True), server_default=func.now(), nullable=False, index=True)
    last_seen = mapped_column(TIMESTAMP(timezone=True), server_default=func.now(), nullable=False, index=True)
    zone_id = mapped_column(UUID(as_uuid=True), ForeignKey("zones.id"), nullable=True, index=True)
    active = mapped_column(Boolean, nullable=False, default=True, index=True)
    __table_args__ = (UniqueConstraint("tld","fqdn", name="uq_domains_tld_fqdn"),)

class Brand(Base):
    __tablename__ = "brands"
    id = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name = mapped_column(String, unique=True, nullable=False)
    official_domains = mapped_column(JSONB, nullable=False)
    keywords = mapped_column(JSONB, nullable=True)
    min_roots = mapped_column(Integer, nullable=False, default=2)
    strict_gate = mapped_column(Boolean, nullable=False, default=True)
    active = mapped_column(Boolean, nullable=False, default=True)
    created_at = mapped_column(TIMESTAMP(timezone=True), server_default=func.now())
    updated_at = mapped_column(TIMESTAMP(timezone=True), server_default=func.now(), onupdate=func.now())

import enum
class TicketStatus(str, enum.Enum):
    descartado = "descartado"
    cuarentena = "cuarentena"
    incidente = "incidente"
    tratamiento_interno = "tratamiento_interno"
    takedown = "takedown"

class Ticket(Base):
    __tablename__ = "tickets"
    id = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    domain_id = mapped_column(UUID(as_uuid=True), ForeignKey("domains.id"), nullable=False, index=True)
    brand_id = mapped_column(UUID(as_uuid=True), ForeignKey("brands.id"), nullable=False, index=True)
    status = mapped_column(Enum(TicketStatus, name="ticket_status"), nullable=False, index=True)
    severity = mapped_column(Integer, nullable=False, default=0)
    title = mapped_column(String, nullable=False)
    description = mapped_column(String, nullable=True)
    created_at = mapped_column(TIMESTAMP(timezone=True), server_default=func.now(), nullable=False, index=True)
    updated_at = mapped_column(TIMESTAMP(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False, index=True)
    __table_args__ = (UniqueConstraint("domain_id","brand_id", name="tickets_domain_id_brand_id_key"),)

class TicketEvent(Base):
    __tablename__ = "ticket_events"
    id = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    ticket_id = mapped_column(UUID(as_uuid=True), ForeignKey("tickets.id"), nullable=False, index=True)
    actor = mapped_column(String, nullable=False)
    action = mapped_column(String, nullable=False)
    details = mapped_column(JSONB, nullable=True)
    created_at = mapped_column(TIMESTAMP(timezone=True), server_default=func.now(), nullable=False, index=True)

class Analysis(Base):
    __tablename__ = "analyses"
    id = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    domain_id = mapped_column(UUID(as_uuid=True), ForeignKey("domains.id"), nullable=False, index=True)
    brand_id  = mapped_column(UUID(as_uuid=True), ForeignKey("brands.id"), nullable=False, index=True)
    score = mapped_column(Float, nullable=False)
    verdict = mapped_column(String, nullable=True)
    vectors = mapped_column(JSONB, nullable=True)
    method_version = mapped_column(String, nullable=True)
    created_at = mapped_column(TIMESTAMP(timezone=True), server_default=func.now(), nullable=False, index=True)
