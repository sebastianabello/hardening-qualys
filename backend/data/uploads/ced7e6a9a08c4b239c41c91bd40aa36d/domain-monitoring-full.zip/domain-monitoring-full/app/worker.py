import os, pathlib, hashlib
from datetime import datetime, timezone
from sqlalchemy import select, text
from celery import group
from .celery_app import celery_app
from .settings import settings
from .czds_client import CZDSClient
from .ingestion_lib import parse_zone_gz, upsert_domains
from .db import SessionLocal
from .models import Zone

def sha256_file(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024*1024), b""):
            h.update(chunk)
    return h.hexdigest()

@celery_app.task(name="ingestion.czds_tld")
def ingestion_czds_tld(url: str, token: str) -> dict:
    tld = url.split("/")[-1].replace(".zone", "")
    dl_dir = settings.DOWNLOAD_DIR
    pathlib.Path(dl_dir).mkdir(parents=True, exist_ok=True)
    gz_path = f"{dl_dir}/{tld}.txt.gz"
    try:
        client = CZDSClient(settings.CZDS_USERNAME, settings.CZDS_PASSWORD, settings.USER_AGENT)
        client.set_token(token)
        client.download_zone(url, gz_path, max_attempts=6, sleep_base=1.0)

        file_sha = sha256_file(gz_path)
        run_ts = datetime.now(timezone.utc)

        db = SessionLocal()
        already = db.execute(
            select(Zone.id).where(
                Zone.tld == tld,
                Zone.sha256 == file_sha,
                Zone.collected_at >= run_ts.replace(hour=0, minute=0, second=0, microsecond=0),
            )
        ).first()
        if already:
            db.close()
            return {"tld": tld, "ok": True, "skipped": True, "reason": "same hash today"}

        z = Zone(
            tld=tld,
            collected_at=run_ts,
            file_name=os.path.basename(gz_path),
            bytes=os.path.getsize(gz_path),
            sha256=file_sha
        )
        db.add(z); db.commit(); db.refresh(z)
        z_id = str(z.id); db.close()

        processed_inserted = 0
        processed_seen = 0
        for chunk in parse_zone_gz(gz_path, chunk_size=20000):
            res = upsert_domains(chunk, zone_id=z_id)
            if isinstance(res, dict):
                processed_inserted += int(res.get("inserted", 0))
                processed_seen += int(res.get("seen", len(chunk)))
            else:
                processed_inserted += int(res)
                processed_seen += len(chunk)

        db = SessionLocal()
        res = db.execute(text("""
                              UPDATE domains
                              SET active = FALSE
                              WHERE tld = :tld
                                AND zone_id IS DISTINCT
                              FROM :zid AND active = TRUE
                              """), {"tld": tld, "zid": z_id})
        db.commit()
        deactivated = res.rowcount or 0
        db.close()

        return {
            "tld": tld,
            "ok": True,
            "processed_rows": processed_seen,
            "inserted": processed_inserted,
            "zone_id": z_id,
            "deactivated": deactivated
        }
    except Exception as e:
        return {"tld": tld, "ok": False, "error": str(e)}

@celery_app.task(name="ingestion.czds")
def ingestion_czds() -> dict:
    client = CZDSClient(settings.CZDS_USERNAME, settings.CZDS_PASSWORD, settings.USER_AGENT)
    token = client.authenticate()
    links = client.links()
    tasks = [ingestion_czds_tld.s(url, token) for url in links]
    gr = group(tasks).apply_async()
    return {"ok": True, "group_id": gr.id, "tlds": len(links)}
