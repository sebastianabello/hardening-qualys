import gzip, re
from typing import Iterable, List, Tuple, Optional
from sqlalchemy import text
from .db import SessionLocal

OWNER_RE = re.compile(r"^\s*([^\s\t]+)")

def extract_owner(line: str) -> str | None:
    m = OWNER_RE.match(line)
    if not m: return None
    owner = m.group(1)
    if owner.startswith(";"): return None
    owner = owner.strip().rstrip(".").lower()
    if "." not in owner: return None
    return owner

def parse_zone_gz(gz_path: str, chunk_size: int = 20000) -> Iterable[List[Tuple[str, str, str, str]]]:
    batch: List[Tuple[str, str, str, str]] = []
    with gzip.open(gz_path, "rt", encoding="utf-8", errors="ignore") as f:
        for line in f:
            owner = extract_owner(line)
            if not owner: continue
            parts = owner.split(".")
            tld = parts[-1]
            fqdn = owner
            sld = ".".join(parts[-2:])
            label_no_tld = ".".join(parts[:-1])
            batch.append((tld, fqdn, sld, label_no_tld))
            if len(batch) >= chunk_size:
                yield batch; batch = []
    if batch: yield batch

def upsert_domains(rows: List[Tuple[str, str, str, str]], zone_id: Optional[str] = None):
    """
    rows: [(tld, fqdn, sld, label_no_tld), ...]
    Devuelve {'inserted': X, 'seen': Y}
    - Para existentes: last_seen=now(), zone_id=:zid, active=TRUE
    - Para nuevos:     first_seen/last_seen=now(), zone_id=:zid, active=TRUE
    """
    if not rows:
        return {"inserted": 0, "seen": 0}

    db = SessionLocal()
    inserted_total = 0
    seen_total = 0

    try:
        db.execute(text("""
            INSERT INTO domains_counters (id, total_domains, updated_at)
            VALUES (1, 0, now())
            ON CONFLICT (id) DO NOTHING
        """))
        db.commit()

        CHUNK = 10000
        for i in range(0, len(rows), CHUNK):
            chunk = rows[i:i+CHUNK]
            seen_total += len(chunk)

            # 1) Tabla temporal
            db.execute(text("""
                CREATE TEMP TABLE tmp_batch (
                    tld TEXT,
                    fqdn TEXT,
                    sld TEXT,
                    label_no_tld TEXT
                ) ON COMMIT DROP
            """))

            # 2) Carga batch
            db.execute(
                text("INSERT INTO tmp_batch (tld, fqdn, sld, label_no_tld) VALUES (:tld, :fqdn, :sld, :label)"),
                [{"tld": t, "fqdn": f, "sld": s, "label": l} for (t, f, s, l) in chunk]
            )

            # 3) Actualiza EXISTENTES con zone_id y active
            db.execute(text("""
                UPDATE domains d
                   SET last_seen = now(),
                       zone_id   = COALESCE(:zid, zone_id),
                       active    = TRUE
                  FROM tmp_batch t
                 WHERE d.tld = t.tld AND d.fqdn = t.fqdn
            """), {"zid": zone_id})

            # 4) Inserta NUEVOS con zone_id y active
            new_count = db.execute(text("""
                WITH ins AS (
                    INSERT INTO domains (tld, fqdn, sld, label_no_tld, first_seen, last_seen, zone_id, active)
                    SELECT t.tld, t.fqdn, t.sld, t.label_no_tld, now(), now(), :zid, TRUE
                      FROM tmp_batch t
                    ON CONFLICT (tld, fqdn) DO NOTHING
                    RETURNING 1
                )
                SELECT COUNT(*) FROM ins
            """), {"zid": zone_id}).scalar() or 0

            inserted_total += int(new_count)
            if new_count:
                db.execute(text("""
                    UPDATE domains_counters
                       SET total_domains = total_domains + :n,
                           updated_at    = now()
                     WHERE id = 1
                """), {"n": int(new_count)})
            db.commit()

    except Exception:
        db.rollback()
        raise
    finally:
        db.close()

    return {"inserted": inserted_total, "seen": seen_total}

