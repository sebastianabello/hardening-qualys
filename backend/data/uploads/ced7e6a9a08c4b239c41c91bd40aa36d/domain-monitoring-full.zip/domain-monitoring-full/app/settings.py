from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    DATABASE_URL: str = "postgresql+psycopg2://app:app@db:5432/domains"
    REDIS_URL: str = "redis://redis:6379/0"
    CZDS_USERNAME: str | None = None
    CZDS_PASSWORD: str | None = None
    URLSCAN_API_KEY: str | None = None
    USER_AGENT: str = "domain-monitoring-mvp/0.1 (+ingestion)"
    DOWNLOAD_DIR: str = "/app/downloads"

    ANALYSIS_MIN_TRGM: float = 0.15
    ANALYSIS_BATCH_SIZE: int = 2000
    INCIDENT_THRESHOLD: float = 0.82
    QUARANTINE_THRESHOLD: float = 0.60
    DESCARTAR_THRESHOLD: float = 0.45
    ANALYSIS_SINCE_HOURS: int = 24

settings = Settings()
