from typing import List, Dict, Any
from sqlalchemy import text, select
from sqlalchemy.exc import IntegrityError
from celery import group
from .celery_app import celery_app
from .settings import settings
from .db import SessionLocal
from .models import Brand, Domain, Analysis, Ticket, TicketStatus, TicketEvent
from .utils.analysis_utils import (
    features, score_from_features, split_label_stems,
    tokens, norm_label, brand_roots_from_keywords, roots_match_count
)

ROOTS_BONUS_BOTH = 0.15
ROOTS_BONUS_ONE  = 0.05

def _brand_labels(brand: Brand) -> List[str]:
    labels = set()
    for fq in brand.official_domains or []:
        fq = fq.lower().strip(".")
        parts = fq.split(".")
        if len(parts) > 1:
            labels.add(".".join(parts[:-1]))
        elif len(parts) == 1 and parts[0]:
            labels.add(parts[0])
    return list(labels)

@celery_app.task(name="analysis.process_chunk")
def process_chunk(brand_id: str, label: str, domain_ids: List[str]) -> Dict[str, Any]:
    db = SessionLocal()
    try:
        brand = db.get(Brand, brand_id)
        if not brand:
            return {"ok": False, "error": "brand not found"}

        inc = settings.INCIDENT_THRESHOLD
        qua = settings.QUARANTINE_THRESHOLD
        desc = settings.DESCARTAR_THRESHOLD

        roots = brand_roots_from_keywords(brand.keywords, label)
        min_roots = max(1, brand.min_roots or 2)
        strict_gate = True if brand.strict_gate is None else brand.strict_gate

        created, updated = 0, 0

        for did in domain_ids:
            d = db.get(Domain, did)
            if not d:
                continue

            v = features(d.label_no_tld, label)
            s = max(score_from_features(v), 0.0)

            from rapidfuzz import fuzz
            cand_toks = tokens(norm_label(d.label_no_tld))
            matches = 0
            for rt in roots:
                if any(fuzz.partial_ratio(rt, ct) >= 80 for ct in cand_toks):
                    matches += 1
            if matches >= len(roots) and len(roots) > 0:
                s += ROOTS_BONUS_BOTH
            elif matches >= 1 and (v["jw"] >= 0.55 or v["skel"] >= 0.60):
                s += ROOTS_BONUS_ONE

            db.add(Analysis(
                domain_id=d.id, brand_id=brand.id, score=float(s),
                verdict=None, vectors=v, method_version="v3"
            ))

            status = None
            if s >= inc:
                status = TicketStatus.incidente
            elif s >= qua:
                status = TicketStatus.cuarentena
            elif s < desc:
                status = TicketStatus.descartado

            if strict_gate and matches < min_roots:
                continue
            if status is None:
                continue

            new_sev = int(round(s * 100))
            title = f"{d.fqdn} ~ {label} ({s:.2f})"

            t = db.execute(
                select(Ticket).where(Ticket.domain_id == d.id, Ticket.brand_id == brand.id)
            ).scalar_one_or_none()

            if t is None:
                try:
                    t = Ticket(domain_id=d.id, brand_id=brand.id, status=status, severity=new_sev, title=title, description=None)
                    db.add(t); db.flush()
                    db.add(TicketEvent(ticket_id=t.id, actor="analysis", action="create",
                                       details={"score": s, "label": label, "roots": roots, "match_cnt": matches}))
                    created += 1
                except IntegrityError:
                    db.rollback()
                    t = db.execute(
                        select(Ticket).where(Ticket.domain_id == d.id, Ticket.brand_id == brand.id)
                    ).scalar_one_or_none()
                    if t is None:
                        continue

            changed = (t.status != status) or (abs(t.severity - new_sev) >= 5)
            if changed:
                t.status = status; t.severity = new_sev; t.title = title
                db.add(TicketEvent(ticket_id=t.id, actor="analysis", action="status_change",
                                   details={"score": s, "label": label, "roots": roots, "match_cnt": matches}))
                updated += 1

        db.commit()
        return {"ok": True, "created": created, "updated": updated, "label": label}
    finally:
        db.close()

@celery_app.task(name="analysis.brand")
def analysis_brand(brand_id: str, since_hours: int | None = None, active_only: bool = True) -> Dict[str, Any]:
    db = SessionLocal()
    try:
        brand = db.get(Brand, brand_id)
        if not brand or not brand.active:
            return {"ok": False, "error": "brand not found or inactive"}

        db.execute(text("DELETE FROM analyses WHERE brand_id = :b"), {"b": brand_id})
        db.commit()

        labels = _brand_labels(brand)
        if not labels:
            return {"ok": False, "error": "brand has no official_domains labels"}

        since_h = since_hours or settings.ANALYSIS_SINCE_HOURS

        candidates: Dict[str, List[str]] = {}
        for lab in labels:
            stem_a, stem_b = split_label_stems(lab)
            regex_pair = rf"({stem_a}[a-z0-9]{{0,3}}.*{stem_b}[a-z0-9]{{0,3}}|{stem_b}[a-z0-9]{{0,3}}.*{stem_a}[a-z0-9]{{0,3}})"

            q = text(f"""
                SELECT id FROM domains
                WHERE last_seen >= now() - (:since_h || ' hours')::interval
                  {"AND active = TRUE" if active_only else ""}
                  AND (
                        similarity(label_no_tld, :lab) >= :min_trgm
                        OR label_no_tld ILIKE :like_full
                        OR label_no_tld ~* :regex_pair
                  )
                ORDER BY last_seen DESC
                LIMIT 200000
            """)
            rows = db.execute(q, {
                "since_h": since_h,
                "lab": lab,
                "min_trgm": settings.ANALYSIS_MIN_TRGM,
                "like_full": f"%{lab}%",
                "regex_pair": regex_pair,
            }).fetchall()
            candidates[lab] = [str(r[0]) for r in rows]

        batch = settings.ANALYSIS_BATCH_SIZE
        tasks = []
        for lab, ids in candidates.items():
            for i in range(0, len(ids), batch):
                tasks.append(process_chunk.s(brand_id, lab, ids[i:i+batch]))

        if not tasks:
            return {"ok": True, "scheduled": 0}

        res = group(tasks).apply_async()
        return {"ok": True, "scheduled": len(tasks), "group_id": res.id}
    finally:
        db.close()
