from fastapi import APIRouter, Query, Depends
from pydantic import BaseModel
from typing import List, Optional, Dict, Any
from sqlalchemy import text
from datetime import datetime
import json

from ..db import get_db, SessionLocal

router = APIRouter(prefix="/tickets", tags=["tickets"])

# ---- Modelos / constantes ----
ALLOWED = {"descartado", "cuarentena", "incidente", "tratamiento_interno", "takedown"}

class StatusIn(BaseModel):
    status: str

# ---- Endpoints ----
@router.patch("/{ticket_id}/status")
def update_status(ticket_id: str, payload: "StatusIn", db: SessionLocal = Depends(get_db)):
    if payload.status not in ALLOWED:
        return {"ok": False, "error": "estado no permitido"}

    upd = db.execute(text("""
        UPDATE tickets
        SET status = :st, updated_at = now()
        WHERE id = :id
        RETURNING id
    """), {"st": payload.status, "id": ticket_id}).mappings().first()
    if not upd:
        return {"ok": False, "error": "ticket no existe"}

    db.execute(text("""
        INSERT INTO ticket_events (id, ticket_id, actor, action, payload)
        VALUES (gen_random_uuid(), :tid, 'ui', 'status_change', :pl::jsonb)
    """), {
        "tid": ticket_id,
        "pl": json.dumps({"status": payload.status, "at": datetime.utcnow().isoformat()})
    })
    db.commit()
    return {"ok": True, "id": ticket_id, "status": payload.status}

@router.get("/search")
def search_tickets(
    brand_id: Optional[str] = None,
    status: List[str] = Query(default=[]),  # ?status=incidente&status=cuarentena
    q: Optional[str] = None,
    tld: Optional[str] = None,
    sort_by: str = Query("updated_at", pattern="^(updated_at|severity)$"),
    sort_dir: str = Query("desc", pattern="^(asc|desc)$"),
    page: int = 1,
    page_size: int = 20,
    db: SessionLocal = Depends(get_db),
):
    where = ["1=1"]
    params: Dict[str, Any] = {}

    if brand_id:
        where.append("t.brand_id = :brand_id")
        params["brand_id"] = brand_id

    if status:
        # Comparamos casteando la COLUMNA a texto (evitamos castear el bind)
        parts = []
        for i, st in enumerate(status):
            key = f"st{i}"
            parts.append(f"t.status::text = :{key}")
            params[key] = st
        where.append("(" + " OR ".join(parts) + ")")

    if q:
        where.append("d.fqdn ILIKE :q")
        params["q"] = f"%{q}%"

    if tld:
        where.append("d.tld = :tld")
        params["tld"] = tld

    order_col = "t.updated_at" if sort_by == "updated_at" else "t.severity"
    order_dir = "DESC" if sort_dir.lower() == "desc" else "ASC"
    params.update({"limit": page_size, "offset": (page - 1) * page_size})

    sql_list = text(f"""
      SELECT t.id, t.status, t.severity, t.updated_at,
             d.fqdn, d.tld, b.name AS brand
      FROM tickets t
      JOIN domains d ON d.id = t.domain_id
      JOIN brands  b ON b.id = t.brand_id
      WHERE {' AND '.join(where)}
      ORDER BY {order_col} {order_dir}
      LIMIT :limit OFFSET :offset
    """)
    items = [dict(r) for r in db.execute(sql_list, params).mappings().all()]

    sql_count = text(f"""
      SELECT count(*)
      FROM tickets t
      JOIN domains d ON d.id = t.domain_id
      WHERE {' AND '.join(where)}
    """)
    total = db.execute(sql_count, params).scalar()

    return {"items": items, "total": total, "page": page, "page_size": page_size}
