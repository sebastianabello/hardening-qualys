from fastapi import APIRouter, Query, Depends
from sqlalchemy import text
from typing import Optional
import redis, json
from datetime import datetime, timedelta, timezone
from ..db import get_db, SessionLocal
from ..settings import settings
from ..utils.cache import get_or_set_json

router = APIRouter(prefix="/dashboard", tags=["dashboard"])
_r = redis.Redis.from_url(settings.REDIS_URL, decode_responses=True)

def _cache_get(key: str):
    try:
        v = _r.get(key); return json.loads(v) if v else None
    except Exception: return None

def _cache_set(key: str, data, ttl: int = 30):
    try: _r.setex(key, ttl, json.dumps(data, default=str))
    except Exception: pass

@router.get("/summary")
def summary(
    since_hours: int = Query(24, ge=1, le=24*14),
    db: SessionLocal = Depends(get_db),
):
    def build():

        now_utc = datetime.now(timezone.utc)
        since_utc = now_utc - timedelta(hours=since_hours)

        # Nuevos exactos (usa índice ix_domains_first_seen)
        new_domains = db.execute(
            text("SELECT COUNT(*) FROM domains WHERE first_seen >= :since"),
            {"since": since_utc}
        ).scalar()

        # Total exacto (del contador)
        total_exact = db.execute(
            text("SELECT total_domains FROM domains_counters WHERE id=1")
        ).scalar() or 0

        # Marcas activas exacto (normalmente pequeño)
        active_brands = db.execute(text(
            "SELECT COUNT(*) FROM brands WHERE deleted_at IS NULL"
        )).scalar()

        # Abiertos por estado (índices en tickets)
        open_rows = db.execute(text("""
          SELECT status, COUNT(*) c
          FROM tickets
          WHERE status IN ('incidente','cuarentena','tratamiento_interno','takedown')
          GROUP BY 1
        """)).mappings().all()

        return {
            "new_domains": int(new_domains),
            "active_domains": int(total_exact),
            "active_brands": int(active_brands),
            "open_tickets_by_status": list(open_rows),
        }
    cache_key = f"dashboard:summary:{since_hours}"
    try:
        return get_or_set_json(cache_key, 60, build)
    except Exception:
        # Si Redis falla, devolvemos la respuesta "en vivo"
        return build()

@router.get("/timeseries/incidents")
def incidents_timeseries(days: int = Query(30, ge=1, le=365), interval: str = Query("day", regex="^(hour|day)$"),
                         brand_id: Optional[str] = None, tz: str = Query("UTC"), db: SessionLocal = Depends(get_db)):
    step = "hour" if interval == "hour" else "day"
    ck = f"dash:series:{step}:{days}:{brand_id or 'all'}:{tz}"
    if (cached := _cache_get(ck)): return cached
    q = text(f"""
    WITH bounds AS (
      SELECT now() AT TIME ZONE 'UTC' AS ts_end, (now() - (:d || ' days')::interval) AT TIME ZONE 'UTC' AS ts_start
    ),
    series AS (
      SELECT generate_series(date_trunc('{step}', (SELECT ts_start FROM bounds)),
                             date_trunc('{step}', (SELECT ts_end   FROM bounds)),
                             '1 {step}') AS bucket
    ),
    base AS (
      SELECT date_trunc('{step}', timezone(:tz, created_at)) AS bucket, COUNT(*) AS c
      FROM tickets t
      WHERE t.status = 'incidente'
        AND t.created_at >= (SELECT ts_start FROM bounds)
        { "AND t.brand_id = :bid" if brand_id else "" }
      GROUP BY 1
    )
    SELECT s.bucket, COALESCE(b.c, 0) AS count
    FROM series s LEFT JOIN base b ON b.bucket = s.bucket
    ORDER BY s.bucket;
    """)
    params = {"d": days, "tz": tz}
    if brand_id: params["bid"] = brand_id
    rows = [{"bucket": r[0].isoformat(), "count": r[1]} for r in db.execute(q, params).all()]
    data = {"interval": step, "days": days, "brand_id": brand_id, "series": rows}
    _cache_set(ck, data, ttl=30); return data

@router.get("/top/tlds")
def top_tlds(since_hours: int = Query(24, ge=1, le=720), brand_id: Optional[str] = None,
             status: Optional[str] = Query(None, regex="^(incidente|cuarentena|descartado|takedown|tratamiento_interno)$"),
             limit: int = Query(15, ge=1, le=100), db: SessionLocal = Depends(get_db)):
    ck = f"dash:top:tlds:{since_hours}:{brand_id or 'all'}:{status or 'all'}:{limit}"
    if (cached := _cache_get(ck)): return cached
    q = text(f"""
    SELECT d.tld, COUNT(*) AS c
    FROM tickets t
    JOIN domains d ON d.id = t.domain_id
    WHERE t.updated_at >= now() - (:h || ' hours')::interval
      { "AND t.brand_id = :bid" if brand_id else "" }
      { "AND t.status = :st" if status else "" }
    GROUP BY d.tld
    ORDER BY c DESC
    LIMIT :lim
    """)
    params = {"h": since_hours, "lim": limit}
    if brand_id: params["bid"] = brand_id
    if status: params["st"] = status
    rows = [dict(r) for r in db.execute(q, params).mappings().all()]
    data = {"since_hours": since_hours, "brand_id": brand_id, "status": status, "items": rows}
    _cache_set(ck, data, ttl=30); return data

@router.get("/activity")
def activity(limit: int = Query(50, ge=1, le=200), db: SessionLocal = Depends(get_db)):
    ck = f"dash:activity:{limit}"
    if (cached := _cache_get(ck)): return cached
    q = text("""
    SELECT te.created_at, te.action, te.actor, te.details,
           t.id AS ticket_id, t.status, t.severity, t.title,
           d.fqdn, b.name AS brand
    FROM ticket_events te
    JOIN tickets t ON t.id = te.ticket_id
    JOIN domains d ON d.id = t.domain_id
    JOIN brands  b ON b.id = t.brand_id
    ORDER BY te.created_at DESC
    LIMIT :lim
    """)
    rows = []
    import json as _json
    for r in db.execute(q, {"lim": limit}).mappings().all():
        item = dict(r)
        if isinstance(item.get("details"), str):
            try: item["details"] = _json.loads(item["details"])
            except Exception: pass
        rows.append(item)
    data = {"items": rows}
    _cache_set(ck, data, ttl=10); return data

@router.get("/scores/histogram")
def scores_histogram(brand_id: str, since_hours: int = Query(24, ge=1, le=720),
                     buckets: int = Query(20, ge=5, le=100), db: SessionLocal = Depends(get_db)):
    ck = f"dash:hist:{brand_id}:{since_hours}:{buckets}"
    if (cached := _cache_get(ck)): return cached
    q = text("""
    WITH base AS (
      SELECT score FROM analyses
      WHERE brand_id = :bid AND created_at >= now() - (:h || ' hours')::interval
    )
    SELECT width_bucket(score, 0, 1, :b) AS bucket, COUNT(*) AS c, MIN(score) AS min_s, MAX(score) AS max_s
    FROM base GROUP BY bucket ORDER BY bucket;
    """)
    rows = [dict(r) for r in db.execute(q, {"bid": brand_id, "h": since_hours, "b": buckets}).mappings().all()]
    data = {"brand_id": brand_id, "since_hours": since_hours, "buckets": buckets, "histogram": rows}
    _cache_set(ck, data, ttl=30); return data

@router.get("/recent_tickets")
def recent_tickets(since_hours: int = Query(24, ge=1, le=720),
                   brand_id: Optional[str] = None,
                   status: Optional[str] = Query(None, regex="^(incidente|cuarentena|descartado|takedown|tratamiento_interno)$"),
                   limit: int = Query(100, ge=1, le=500), db: SessionLocal = Depends(get_db)):
    ck = f"dash:recent:{since_hours}:{brand_id or 'all'}:{status or 'all'}:{limit}"
    if (cached := _cache_get(ck)): return cached
    q = text(f"""
    SELECT t.id AS ticket_id, t.status, t.severity, t.title, t.created_at, t.updated_at,
           d.fqdn, d.tld, b.name AS brand
    FROM tickets t
    JOIN domains d ON d.id = t.domain_id
    JOIN brands  b ON b.id = t.brand_id
    WHERE t.updated_at >= now() - (:h || ' hours')::interval
      { "AND t.brand_id = :bid" if brand_id else "" }
      { "AND t.status = :st" if status else "" }
    ORDER BY t.updated_at DESC
    LIMIT :lim
    """)
    params = {"h": since_hours, "lim": limit}
    if brand_id: params["bid"] = brand_id
    if status: params["st"] = status
    rows = [dict(r) for r in db.execute(q, params).mappings().all()]
    data = {"since_hours": since_hours, "brand_id": brand_id, "status": status, "items": rows}
    _cache_set(ck, data, ttl=15); return data

@router.get("/timeseries/domains")
def domains_timeseries(
    interval: str = Query("day", pattern="^(hour|day|week|month)$"),
    start: Optional[str] = Query(None, description="ISO date/time, ej: 2025-08-01"),
    end:   Optional[str] = Query(None, description="ISO date/time, ej: 2025-08-11"),
    metric: str = Query("new", pattern="^(new|seen)$", description="new=first_seen, seen=last_seen"),
    tz: str = Query("UTC"),
    tld: Optional[str] = Query(None),
    db: SessionLocal = Depends(get_db),
):
    """
    Serie de tiempo de dominios:
    - interval: hour|day|week|month
    - metric: new (cuenta por first_seen) | seen (cuenta por last_seen)
    - start/end: rango (si no se envía, usa últimos 30 días)
    - tz: zona horaria para agrupar (ej: America/Bogota)
    - tld: filtra por TLD si se desea
    """
    # Validación simple de interval para usar en f-strings seguros
    step = interval
    time_col = "first_seen" if metric == "new" else "last_seen"

    # Rango por defecto: últimos 30 días
    ts_end = datetime.now(timezone.utc) if end is None else datetime.fromisoformat(end)
    if ts_end.tzinfo is None:
        ts_end = ts_end.replace(tzinfo=timezone.utc)
    ts_start = ts_end - timedelta(days=30) if start is None else datetime.fromisoformat(start)
    if ts_start.tzinfo is None:
        ts_start = ts_start.replace(tzinfo=timezone.utc)

    q = text(f"""
    WITH bounds AS (
      SELECT :ts_start AS ts_start, :ts_end AS ts_end
    ),
    series AS (
      SELECT generate_series(
        date_trunc('{step}', timezone(:tz, (SELECT ts_start FROM bounds))),
        date_trunc('{step}', timezone(:tz, (SELECT ts_end   FROM bounds))),
        '1 {step}'
      ) AS bucket
    ),
    base AS (
      SELECT date_trunc('{step}', timezone(:tz, {time_col})) AS bucket, COUNT(*) AS c
      FROM domains
      WHERE {time_col} >= (SELECT ts_start FROM bounds)
        AND {time_col} <  (SELECT ts_end   FROM bounds)
        {"AND tld = :tld" if tld else ""}
      GROUP BY 1
    )
    SELECT s.bucket, COALESCE(b.c, 0) AS count
    FROM series s
    LEFT JOIN base b ON b.bucket = s.bucket
    ORDER BY s.bucket;
    """)

    params = {"ts_start": ts_start, "ts_end": ts_end, "tz": tz}
    if tld:
        params["tld"] = tld

    rows = [{"bucket": r[0].isoformat(), "count": r[1]} for r in db.execute(q, params).all()]
    return {"interval": step, "metric": metric, "tz": tz, "start": ts_start.isoformat(), "end": ts_end.isoformat(), "series": rows}
