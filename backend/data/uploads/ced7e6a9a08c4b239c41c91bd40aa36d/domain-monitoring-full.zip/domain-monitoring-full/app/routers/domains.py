from fastapi import APIRouter, Body, Depends
from pydantic import BaseModel
from sqlalchemy import text
from typing import List, Dict
from ..db import get_db, SessionLocal
import json

router = APIRouter(prefix="/domains", tags=["domains"])

@router.get("/lookup")
def lookup(fqdn: str, db: SessionLocal = Depends(get_db)):
    row = db.execute(text("""
      SELECT id, fqdn, tld, first_seen, last_seen FROM domains WHERE fqdn=:fqdn
    """), {"fqdn": fqdn}).mappings().first()
    return row or {}

class BulkIn(BaseModel):
    domains: List[str]

@router.post("/bulk_lookup")
def bulk_lookup(payload: BulkIn, db: SessionLocal = Depends(get_db)):
    items = [d.strip().lower() for d in payload.domains if d.strip()]
    if not items:
        return {"found": [], "not_found": []}
    rows = db.execute(text("""
      SELECT id, fqdn, tld, first_seen, last_seen
      FROM domains
      WHERE fqdn = ANY(:arr)
    """), {"arr": items}).mappings().all()
    found = [dict(r) for r in rows]
    found_set = {r["fqdn"] for r in found}
    not_found = [d for d in items if d not in found_set]
    return {"found": found, "not_found": not_found}
