import unicodedata, idna, re
from typing import Dict, Tuple, List
from rapidfuzz.distance import DamerauLevenshtein, JaroWinkler
from rapidfuzz import fuzz

STOPWORDS = {"tu","mi","el","la","los","las","compra","comprar","soat","co","col","www","app","site","online"}
SUSPICIOUS_PREFIXES = {"login","secure","support","verify","update","account","wallet","recover","reset"}

def norm_label(s: str) -> str:
    try:
        s = idna.decode(s.encode("utf-8"))
    except Exception:
        pass
    s = unicodedata.normalize("NFKC", s).lower()
    s = re.sub(r"[._-]+", " ", s)
    s = re.sub(r"\s+", " ", s).strip()
    return s

def tokens(s: str) -> List[str]:
    toks = re.split(r"[^a-z0-9]+", s)
    toks = [t for t in toks if t]
    toks = [t for t in toks if t not in STOPWORDS]
    return toks

def skeleton(s: str) -> str:
    s = re.sub(r"[aeiou]", "", s)
    s = re.sub(r"(.)\1+", r"\1", s)
    return s

def split_label_stems(label: str) -> Tuple[str, str]:
    lab = label.lower().strip(".")
    mid = max(3, len(lab)//2)
    a, b = lab[:mid], lab[mid:]
    return a[:5], b[:5]

def stems_any_order_bonus(candidate_norm_no_space: str, label: str) -> float:
    sa, sb = split_label_stems(label)
    if not sa or not sb: return 0.0
    rx = rf"({sa}[a-z0-9]{{0,3}}.*{sb}|{sb}[a-z0-9]{{0,3}}.*{sa})"
    return 1.0 if re.search(rx, candidate_norm_no_space) else 0.0

def features(candidate: str, official: str) -> Dict[str, float]:
    a_raw = norm_label(candidate); b_raw = norm_label(official)
    a = a_raw.replace(" ", ""); b = b_raw.replace(" ", "")
    jw = JaroWinkler.normalized_similarity(a, b)
    dl = 1 - min(1.0, DamerauLevenshtein.normalized_distance(a, b))
    pr = fuzz.partial_ratio(a, b) / 100.0
    a_tok = " ".join(tokens(a_raw)); b_tok = " ".join(tokens(b_raw))
    tok_set = fuzz.token_set_ratio(a_tok, b_tok) / 100.0
    tok_sort = fuzz.token_sort_ratio(a_tok, b_tok) / 100.0
    sk = fuzz.ratio(skeleton(a), skeleton(b)) / 100.0
    stems_bonus = stems_any_order_bonus(a, b_raw) * 0.10
    token_flag = 0.12 if any(p in a_tok for p in SUSPICIOUS_PREFIXES) else 0.0
    return {"jw": jw, "dl": dl, "partial": pr, "tok_set": tok_set, "tok_sort": tok_sort, "skel": sk, "token": token_flag, "stems_bonus": stems_bonus}

def score_from_features(v: Dict[str, float]) -> float:
    s = (0.20*v["jw"] + 0.22*v["dl"] + 0.14*v["partial"] + 0.22*v["tok_set"] + 0.12*v["tok_sort"] + 0.16*v["skel"] + v.get("token",0.0) + v.get("stems_bonus",0.0))
    return max(0.0, min(1.0, s))

def brand_roots_from_keywords(keywords: List[str] | None, label: str) -> List[str]:
    def _trim_plural(x: str) -> str:
        if len(x) > 4 and x.endswith("es"): return x[:-2]
        if len(x) > 4 and x.endswith("s"):  return x[:-1]
        return x
    roots: List[str] = []
    if keywords:
        for k in keywords:
            k = norm_label(k)
            for t in re.split(r"[^a-z0-9]+", k):
                t = _trim_plural(t)
                if t and len(t) >= 3:
                    roots.append(t[:8])
    else:
        toks = re.split(r"[^a-z0-9]+", norm_label(label))
        for t in toks:
            t = _trim_plural(t)
            if t and len(t) >= 3:
                roots.append(t[:8])
    roots = [r for r in dict.fromkeys(roots)]
    return roots

def roots_match_count(candidate: str, roots: List[str]) -> int:
    cand_toks = tokens(norm_label(candidate))
    matches = 0
    for rt in roots:
        if any(fuzz.partial_ratio(rt, ct) >= 80 for ct in cand_toks):
            matches += 1
    return matches
