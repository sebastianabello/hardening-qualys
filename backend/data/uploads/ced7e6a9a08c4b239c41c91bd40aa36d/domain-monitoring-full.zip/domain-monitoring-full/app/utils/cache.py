import json
import redis
from ..settings import settings

_r = redis.Redis.from_url(settings.REDIS_URL)

def get_or_set_json(key: str, ttl_seconds: int, builder):
    """
    Si existe el key en Redis, lo devuelve (parseado JSON).
    Si no, ejecuta builder(), guarda el resultado como JSON con TTL y lo devuelve.
    """
    cached = _r.get(key)
    if cached:
        try:
            return json.loads(cached)
        except Exception:
            pass  # si falla el parseo, reconstruimos

    value = builder()
    # Nota: default=str para serializar datetimes
    _r.setex(key, ttl_seconds, json.dumps(value, default=str))
    return value
