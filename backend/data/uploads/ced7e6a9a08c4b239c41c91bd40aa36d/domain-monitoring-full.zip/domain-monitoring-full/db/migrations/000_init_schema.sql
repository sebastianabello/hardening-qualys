CREATE EXTENSION IF NOT EXISTS pg_trgm;
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

CREATE TABLE IF NOT EXISTS zones (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  tld text NOT NULL,
  collected_at timestamptz NOT NULL DEFAULT now(),
  file_name text NOT NULL,
  bytes bigint NOT NULL,
  sha256 text NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_zones_tld ON zones(tld);
CREATE INDEX IF NOT EXISTS ix_zones_sha ON zones(sha256);
CREATE INDEX IF NOT EXISTS ix_zones_collected_at ON zones(collected_at DESC);


CREATE TABLE IF NOT EXISTS domains (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  tld text NOT NULL,
  fqdn text NOT NULL,
  sld text NOT NULL,
  label_no_tld text NOT NULL,
  first_seen timestamptz NOT NULL DEFAULT now(),
  last_seen  timestamptz NOT NULL DEFAULT now(),
  zone_id uuid NULL REFERENCES zones(id),
  active boolean NOT NULL DEFAULT TRUE
);
CREATE UNIQUE INDEX IF NOT EXISTS uq_domains_tld_fqdn ON domains(tld, fqdn);
CREATE INDEX IF NOT EXISTS ix_domains_label_trgm ON domains USING gin (label_no_tld gin_trgm_ops);
CREATE INDEX IF NOT EXISTS ix_domains_last_seen ON domains(last_seen);
CREATE INDEX IF NOT EXISTS ix_domains_active   ON domains(active);
CREATE INDEX IF NOT EXISTS ix_domains_tld      ON domains(tld);
CREATE INDEX IF NOT EXISTS ix_domains_tld_zone ON domains(tld, zone_id);
CREATE INDEX IF NOT EXISTS ix_domains_first_seen ON domains(first_seen);
CREATE INDEX IF NOT EXISTS ix_domains_fqdn ON domains(fqdn);

CREATE TABLE IF NOT EXISTS brands (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  name text UNIQUE NOT NULL,
  official_domains jsonb NOT NULL,
  keywords jsonb null,
  min_roots int NOT NULL DEFAULT 2,
  strict_gate boolean NOT NULL DEFAULT TRUE,
  active boolean NOT NULL DEFAULT TRUE,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  deleted_at timestamptz null
);

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'ticket_status') THEN
    CREATE TYPE ticket_status AS ENUM ('descartado','cuarentena','incidente','tratamiento_interno','takedown');
  END IF;
END $$;

CREATE TABLE IF NOT EXISTS tickets (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  domain_id uuid NOT NULL REFERENCES domains(id),
  brand_id  uuid NOT NULL REFERENCES brands(id),
  status ticket_status NOT NULL,
  severity int NOT NULL DEFAULT 0,
  title text NOT NULL,
  description text null,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(domain_id, brand_id)
);
CREATE INDEX IF NOT EXISTS ix_tickets_status ON tickets(status);
CREATE INDEX IF NOT EXISTS ix_tickets_updated_at ON tickets(updated_at DESC);
CREATE INDEX IF NOT EXISTS ix_tickets_brand_status ON tickets(brand_id, status);
CREATE INDEX IF NOT EXISTS ix_tickets_brand_status_updated ON tickets(brand_id, status, updated_at DESC);
CREATE INDEX IF NOT EXISTS ix_tickets_updated ON tickets(updated_at DESC);

CREATE TABLE IF NOT EXISTS ticket_events (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  ticket_id uuid NOT NULL REFERENCES tickets(id),
  actor text NOT NULL,
  action text NOT NULL,
  details jsonb null,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_ticket_events_created ON ticket_events(created_at DESC);
CREATE INDEX IF NOT EXISTS ix_ticket_events_ticket  ON ticket_events(ticket_id, created_at DESC);

CREATE TABLE IF NOT EXISTS analyses (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  domain_id uuid NOT NULL REFERENCES domains(id),
  brand_id  uuid NOT NULL REFERENCES brands(id),
  score float NOT NULL,
  verdict text null,
  vectors jsonb null,
  method_version text null,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_analyses_brand_created ON analyses(brand_id, created_at DESC);

CREATE TABLE IF NOT EXISTS domains_counters (
  id INT PRIMARY KEY DEFAULT 1,
  total_domains BIGINT NOT NULL DEFAULT 0,
  updated_at timestamptz NOT NULL DEFAULT now()
);

INSERT INTO domains_counters (id, total_domains)
SELECT 1, COUNT(*) FROM domains
ON CONFLICT (id)
DO UPDATE SET total_domains = EXCLUDED.total_domains, updated_at = now();

