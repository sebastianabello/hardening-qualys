import httpx, time

AUTH_URL = "https://account-api.icann.org/api/authenticate"
LINKS_URL = "https://czds-api.icann.org/czds/downloads/links"

class CZDSClient:
    def __init__(self, username: str | None, password: str | None, user_agent: str = "domain-monitoring"):
        self.username = username
        self.password = password
        self.user_agent = user_agent
        self._token = None
        self._client = httpx.Client(http2=True, timeout=httpx.Timeout(60.0, read=60.0, connect=30.0))
    def _headers(self):
        h = {"User-Agent": self.user_agent}
        if self._token:
            h["Authorization"] = f"Bearer {self._token}"
        return h
    def authenticate(self) -> str:
        if not self.username or not self.password:
            raise RuntimeError("CZDS credentials missing")
        r = self._client.post(AUTH_URL, json={"username": self.username, "password": self.password}, headers=self._headers())
        r.raise_for_status()
        tok = r.json().get("accessToken") or r.json().get("access_token")
        if not tok:
            raise RuntimeError("No token in auth response")
        self._token = tok
        return tok
    def set_token(self, token: str):
        self._token = token
    def links(self) -> list[str]:
        r = self._client.get(LINKS_URL, headers=self._headers())
        r.raise_for_status()
        return r.json()
    def download_zone(self, url: str, dest_path: str, max_attempts: int = 5, sleep_base: float = 1.0):
        for attempt in range(1, max_attempts+1):
            try:
                with self._client.stream("GET", url, headers=self._headers()) as r:
                    r.raise_for_status()
                    tmp = dest_path + ".part"
                    with open(tmp, "wb") as f:
                        for chunk in r.iter_bytes():
                            f.write(chunk)
                    import os
                    os.replace(tmp, dest_path)
                    return
            except httpx.HTTPError:
                if attempt == max_attempts:
                    raise
                time.sleep(sleep_base * attempt)
