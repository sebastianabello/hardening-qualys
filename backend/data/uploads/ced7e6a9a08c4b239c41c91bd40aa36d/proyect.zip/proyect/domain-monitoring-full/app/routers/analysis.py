from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from celery import group
from celery.result import AsyncResult, GroupResult
from ..db import get_db
from ..models import Brand
from ..analysis_tasks import analysis_brand
from ..celery_app import celery_app

router = APIRouter(prefix="/analysis", tags=["analysis"])

@router.post("/run/{brand_id}")
def run_analysis_brand(brand_id: str, since_hours: int | None = Query(None), active_only: bool = Query(True)):
    res = analysis_brand.delay(brand_id, since_hours, active_only)
    return {"status": "scheduled", "task_id": res.id}

@router.post("/run_all")
def run_all(since_hours: int | None = Query(None), active_only: bool = Query(True), db: Session = Depends(get_db)):
    brands = db.query(Brand).filter(Brand.active == True).all()
    jobs = [analysis_brand.s(str(b.id), since_hours, active_only) for b in brands]
    gr = group(jobs).apply_async()
    return {"status": "scheduled", "group_id": gr.id, "brands": len(brands)}

@router.get("/status/{task_or_group_id}")
def status(task_or_group_id: str):
    ar = AsyncResult(task_or_group_id, app=celery_app)
    if ar.state != "PENDING" or ar.info:
        return {"id": task_or_group_id, "state": ar.state, "info": ar.info}
    gr = GroupResult.restore(task_or_group_id, app=celery_app)
    if gr:
        return {"id": task_or_group_id, "state": gr.state()}
    return {"id": task_or_group_id, "state": "UNKNOWN"}
