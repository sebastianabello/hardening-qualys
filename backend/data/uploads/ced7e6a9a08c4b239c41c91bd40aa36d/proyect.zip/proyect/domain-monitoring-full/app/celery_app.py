from celery import Celery
from .settings import settings

celery_app = Celery("domain_tasks", broker=settings.REDIS_URL, backend=settings.REDIS_URL)
celery_app.conf.worker_prefetch_multiplier = 1

# Import tasks so Celery registers them
from . import worker as _worker  # noqa: F401
from . import analysis_tasks as _analysis  # noqa: F401
