from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
from ..db import get_db
from .. import models, schemas

router = APIRouter(prefix="/brands", tags=["brands"])

@router.post("", response_model=schemas.BrandOut)
def create_brand(payload: schemas.BrandCreate, db: Session = Depends(get_db)):
    b = models.Brand(
        name=payload.name,
        official_domains=payload.official_domains,
        keywords=payload.keywords,
        min_roots=payload.min_roots or 2,
        strict_gate=payload.strict_gate if payload.strict_gate is not None else True,
    )
    db.add(b); db.commit(); db.refresh(b)
    return b

@router.get("", response_model=List[schemas.BrandOut])
def list_brands(db: Session = Depends(get_db)):
    return db.query(models.Brand).all()
