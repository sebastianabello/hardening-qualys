import gzip, re
from typing import Iterable, List, Tuple
from psycopg2.extras import execute_values
from .db import SessionLocal

OWNER_RE = re.compile(r"^\s*([^\s\t]+)")

def extract_owner(line: str) -> str | None:
    m = OWNER_RE.match(line)
    if not m: return None
    owner = m.group(1)
    if owner.startswith(";"): return None
    owner = owner.strip().rstrip(".").lower()
    if "." not in owner: return None
    return owner

def parse_zone_gz(gz_path: str, chunk_size: int = 20000) -> Iterable[List[Tuple[str, str, str, str]]]:
    batch: List[Tuple[str, str, str, str]] = []
    with gzip.open(gz_path, "rt", encoding="utf-8", errors="ignore") as f:
        for line in f:
            owner = extract_owner(line)
            if not owner: continue
            parts = owner.split(".")
            tld = parts[-1]
            fqdn = owner
            sld = ".".join(parts[-2:])
            label_no_tld = ".".join(parts[:-1])
            batch.append((tld, fqdn, sld, label_no_tld))
            if len(batch) >= chunk_size:
                yield batch; batch = []
    if batch: yield batch

def upsert_domains_fast(rows: List[Tuple[str, str, str, str]], zone_id: str | None = None) -> int:
    if not rows: return 0
    db = SessionLocal()
    conn = db.connection().connection
    cur = conn.cursor()
    try:
        cur.execute("SET LOCAL synchronous_commit = OFF")
    except Exception:
        pass
    seen = set(); data = []
    for t,f,s,l in rows:
        key = (t,f)
        if key in seen: continue
        seen.add(key)
        if zone_id: data.append((t,f,s,l,zone_id))
        else:       data.append((t,f,s,l))
    if zone_id:
        sql = """
            INSERT INTO domains (tld, fqdn, sld, label_no_tld, first_seen, last_seen, zone_id, active)
            VALUES %s
            ON CONFLICT (tld, fqdn) DO UPDATE SET
                last_seen = EXCLUDED.last_seen,
                zone_id   = EXCLUDED.zone_id,
                active    = TRUE
        """
        template = "(%s,%s,%s,%s, now(), now(), %s, TRUE)"
    else:
        sql = """
            INSERT INTO domains (tld, fqdn, sld, label_no_tld, first_seen, last_seen, active)
            VALUES %s
            ON CONFLICT (tld, fqdn) DO UPDATE SET
                last_seen = EXCLUDED.last_seen,
                active    = TRUE
        """
        template = "(%s,%s,%s,%s, now(), now(), TRUE)"
    execute_values(cur, sql, data, template=template, page_size=20000)
    conn.commit(); cur.close(); db.close()
    return len(data)
