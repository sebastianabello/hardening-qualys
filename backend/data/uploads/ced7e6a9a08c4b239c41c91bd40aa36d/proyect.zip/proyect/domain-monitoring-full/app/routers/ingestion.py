from fastapi import APIRouter
from ..celery_app import celery_app
from ..worker import ingestion_czds
from celery.result import AsyncResult, GroupResult

router = APIRouter(prefix="/ingestion", tags=["ingestion"])

@router.post("/run")
def run_ingestion():
    res = ingestion_czds.delay()
    return {"status": "queued", "task_id": res.id}

@router.get("/status/{task_or_group_id}")
def status(task_or_group_id: str):
    ar = AsyncResult(task_or_group_id, app=celery_app)
    if ar.state != "PENDING" or ar.info:
        return {"id": task_or_group_id, "state": ar.state, "info": ar.info}
    gr = GroupResult.restore(task_or_group_id, app=celery_app)
    if gr:
        return {"id": task_or_group_id, "state": gr.state()}
    return {"id": task_or_group_id, "state": "UNKNOWN"}
