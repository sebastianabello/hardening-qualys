from pydantic import BaseModel
from typing import List, Optional
from uuid import UUID
from datetime import datetime

class BrandCreate(BaseModel):
    name: str
    official_domains: List[str]
    keywords: Optional[List[str]] = None
    min_roots: Optional[int] = 2
    strict_gate: Optional[bool] = True

class BrandOut(BaseModel):
    id: UUID
    name: str
    official_domains: List[str]
    keywords: Optional[List[str]] = None
    min_roots: int
    strict_gate: bool
    active: bool
    created_at: datetime
    updated_at: datetime
    class Config:
        from_attributes = True
