const API_BASE = import.meta.env.VITE_API_BASE || 'http://localhost:8000';

function q(params) {
  const s = new URLSearchParams();
  Object.entries(params).forEach(([k, v]) => {
    if (v === undefined || v === null || v === '') return;
    s.set(k, String(v));
  });
  return s.toString();
}

async function j(url) {
  const r = await fetch(url);
  if (!r.ok) throw new Error(`${r.status} ${url}`);
  return r.json();
}

export const api = {
  summary: (since_hours = 24) => j(`${API_BASE}/dashboard/summary?since_hours=${since_hours}`),
  brands: () => j(`${API_BASE}/brands`),
  series: (p = {}) => j(`${API_BASE}/dashboard/timeseries/incidents?${q(p)}`),
  topTlds: (p = {}) => j(`${API_BASE}/dashboard/top/tlds?${q(p)}`),
  activity: (limit = 25) => j(`${API_BASE}/dashboard/activity?limit=${limit}`),
  tickets: (p = {}) => j(`${API_BASE}/dashboard/recent_tickets?${q(p)}`),
  histogram: (brand_id, since_hours = 24, buckets = 20) => j(`${API_BASE}/dashboard/scores/histogram?brand_id=${brand_id}&since_hours=${since_hours}&buckets=${buckets}`),
  domainsSeries: (p = {}) => {
    const qs = new URLSearchParams();
    if (p.interval) qs.set('interval', p.interval);
    if (p.metric) qs.set('metric', p.metric);
    if (p.start) qs.set('start', p.start);
    if (p.end) qs.set('end', p.end);
    if (p.tz) qs.set('tz', p.tz);
    if (p.tld) qs.set('tld', p.tld);
    return fetch(`${(import.meta.env.VITE_API_BASE || 'http://localhost:8000')}/dashboard/timeseries/domains?` + qs.toString())
      .then(r => { if (!r.ok) throw new Error('domainsSeries'); return r.json(); });
  }
}
