import { useEffect, useMemo, useState } from "react";
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, BarChart, Bar } from "recharts";
import { api } from "./api";


function numberFmt(n){
  if (n === undefined || n === null) return "—";
  return new Intl.NumberFormat().format(n);
}

export default function App(){
  const [since, setSince] = useState(24);
  const [brand, setBrand] = useState('');
  const [brands, setBrands] = useState([]);

  const [summary, setSummary] = useState(null);
  const [series, setSeries] = useState({series:[]});
  const [tops, setTops] = useState({items:[]});
  const [activity, setActivity] = useState({items:[]});
  const [tickets, setTickets] = useState({items:[]});

  const [domInterval, setDomInterval] = useState('day');     // 'day' | 'week' | 'month'
  const [domMetric, setDomMetric]   = useState('new');       // 'new' | 'seen'
  const [startDate, setStartDate]   = useState(() => new Date(Date.now()-30*864e5).toISOString().slice(0,10));
  const [endDate, setEndDate]       = useState(() => new Date().toISOString().slice(0,10));
  const [domSeries, setDomSeries]   = useState({series:[]});

  // load brands
  useEffect(()=>{ api.brands().then(setBrands).catch(console.error) },[]);

  // load dashboard data
  useEffect(()=>{ api.summary(since).then(setSummary).catch(console.error) }, [since]);
  useEffect(()=>{ api.series({days:30, interval:'day', brand_id: brand||undefined}).then(setSeries).catch(console.error) }, [brand]);
  useEffect(()=>{ api.topTlds({since_hours: since, brand_id: brand||undefined, status:'incidente', limit:10}).then(setTops).catch(console.error) }, [since, brand]);
  useEffect(()=>{ api.activity(20).then(setActivity).catch(console.error) }, []);
  useEffect(()=>{ api.tickets({since_hours: since, brand_id: brand||undefined, limit: 20}).then(setTickets).catch(console.error) }, [since, brand]);
  useEffect(()=>{
    api.domainsSeries({
      interval: domInterval,
      metric: domMetric,
      start: startDate, // 'YYYY-MM-DD'
      end: endDate,
      tz: 'America/Bogota'
    }).then(setDomSeries).catch(console.error);
  }, [domInterval, domMetric, startDate, endDate]);

  const domData = (domSeries?.series||[]).map(x=>({
    bucket: new Date(x.bucket).toLocaleDateString(),
    count: x.count
  }));

  const incidenteOpen = useMemo(()=>{
    const st = summary?.open_tickets_by_status || [];
    const obj = Object.fromEntries(st.map(s=>[s.status, s.c]));
    return obj['incidente'] || 0;
  }, [summary]);

  const areaData = (series?.series || []).map(x=>({ day: new Date(x.bucket).toLocaleDateString(), sessions: x.count }));
  const barData = (tops?.items || []).map(x=>({ month: x.tld, pv: x.c }));



  return (
    <div className="min-h-screen bg-[#f7f9fc] text-gray-800">
      <div className="flex">
        {/* Sidebar */}
        <aside className="w-64 bg-white border-r border-gray-200 h-screen">
          <div className="p-4 flex items-center gap-2">
            <div className="w-8 h-8 rounded bg-blue-600" />
            <div>
              <div className="font-semibold">Domain Monitor</div>
              <div className="text-xs text-gray-500">Web app</div>
            </div>
          </div>
          <nav className="px-2 space-y-1">
            <a className="flex items-center px-3 py-2 rounded-md text-sm font-medium bg-gray-100">Home</a>
            <a className="flex items-center px-3 py-2 rounded-md text-sm font-medium hover:bg-gray-100">Analytics</a>
            <a className="flex items-center px-3 py-2 rounded-md text-sm font-medium hover:bg-gray-100">Tickets</a>
            <a className="flex items-center px-3 py-2 rounded-md text-sm font-medium hover:bg-gray-100">Settings</a>
          </nav>
        </aside>

        {/* Main */}
        <main className="flex-1">
          {/* Header */}
          <header className="flex items-center justify-between px-6 py-3 border-b bg-white">
            <div className="text-sm text-gray-500">Dashboard &gt; <span className="text-gray-900 font-medium">Home</span></div>
            <div className="flex items-center gap-3">
              <select className="border rounded-md px-3 py-2" value={since} onChange={e=>setSince(Number(e.target.value))}>
                <option value={6}>Últimas 6h</option>
                <option value={24}>Últimas 24h</option>
                <option value={72}>Últimas 72h</option>
                <option value={168}>Últimos 7 días</option>
              </select>
              <select className="border rounded-md px-3 py-2" value={brand} onChange={e=>setBrand(e.target.value)}>
                <option value="">Todas las marcas</option>
                {brands.map(b=> <option key={b.id} value={b.id}>{b.name}</option>)}
              </select>
            </div>
          </header>

          <section className="p-6">
            {/* KPIs */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
              <div className="bg-white rounded-xl border p-4">
                <div className="text-sm text-gray-500">Dominios nuevos</div>
                <div className="mt-2 text-2xl font-semibold">{numberFmt(summary?.new_domains)}</div>
              </div>
              <div className="bg-white rounded-xl border p-4">
                <div className="text-sm text-gray-500">Dominios activos</div>
                <div className="mt-2 text-2xl font-semibold">{numberFmt(summary?.active_domains)}</div>
              </div>
              <div className="bg-white rounded-xl border p-4">
                <div className="text-sm text-gray-500">Marcas activas</div>
                <div className="mt-2 text-2xl font-semibold">{numberFmt(summary?.active_brands)}</div>
              </div>
              <div className="bg-white rounded-xl border p-4">
                <div className="text-sm text-gray-500">Incidentes abiertos</div>
                <div className="mt-2 text-2xl font-semibold">{numberFmt(incidenteOpen)}</div>
              </div>
            </div>

            {/* Charts */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-6">
              <div className="bg-white rounded-xl border p-4 lg:col-span-2">
                <div className="text-sm font-medium text-gray-700 mb-3">Incidentes por día (30 días)</div>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={areaData}>
                      <defs>
                        <linearGradient id="colorUv" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.4}/>
                          <stop offset="95%" stopColor="#3b82f6" stopOpacity={0.05}/>
                        </linearGradient>
                      </defs>
                      <XAxis dataKey="day" />
                      <YAxis allowDecimals={false}/>
                      <Tooltip />
                      <Area type="monotone" dataKey="sessions" stroke="#3b82f6" fillOpacity={1} fill="url(#colorUv)" />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </div>
              <div className="bg-white rounded-xl border p-4">
                <div className="text-sm font-medium text-gray-700 mb-3">Top TLDs en incidentes</div>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={barData}>
                      <XAxis dataKey="month" />
                      <YAxis allowDecimals={false}/>
                      <Tooltip />
                      <Bar dataKey="pv" fill="#60a5fa" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </div>

            {/* Recent tickets table */}
            <div className="bg-white rounded-xl border p-4">
              <div className="text-sm font-medium text-gray-700 mb-3">Tickets recientes</div>
              <div className="overflow-auto">
                <table className="min-w-full text-sm">
                  <thead className="text-left text-gray-500">
                    <tr>
                      <th className="py-2 pr-4">Dominio</th>
                      <th className="py-2 pr-4">Brand</th>
                      <th className="py-2 pr-4">TLD</th>
                      <th className="py-2 pr-4">Status</th>
                      <th className="py-2 pr-4">Severity</th>
                      <th className="py-2 pr-4">Actualizado</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y">
                    {(tickets?.items||[]).map((it, idx)=>(
                      <tr key={idx}>
                        <td className="py-2 pr-4 font-medium text-gray-900">{it.fqdn}</td>
                        <td className="py-2 pr-4">{it.brand}</td>
                        <td className="py-2 pr-4">{it.tld}</td>
                        <td className="py-2 pr-4">{it.status}</td>
                        <td className="py-2 pr-4">{it.severity}</td>
                        <td className="py-2 pr-4 text-gray-500">{new Date(it.updated_at).toLocaleString()}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Activity */}
            <div className="bg-white rounded-xl border p-4 mt-4">
              <div className="text-sm font-medium text-gray-700 mb-3">Actividad reciente</div>
              <ul className="divide-y">
                {(activity?.items||[]).map((it, idx)=>(
                  <li key={idx} className="py-3">
                    <div className="text-sm text-gray-900"><span className="font-medium">{it.action}</span> · {it.status} · <span className="text-gray-600">{it.fqdn}</span></div>
                    <div className="text-xs text-gray-500">{new Date(it.created_at).toLocaleString()} · {it.brand}</div>
                  </li>
                ))}
              </ul>
            </div>
          </section>
        </main>
      </div>
    </div>
  );
}
