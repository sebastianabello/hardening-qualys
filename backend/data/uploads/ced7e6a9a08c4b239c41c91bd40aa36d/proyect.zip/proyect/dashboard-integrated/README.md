# Dashboard base (Vite + React + Tailwind + Recharts + Docker)

## Dev
```bash
npm i
npm run dev
```

## Build
```bash
npm run build
npm run preview
```

## Docker (production)
```bash
docker build -t dashboard:v1 .
docker run -p 8080:80 dashboard:v1
# open http://localhost:8080
```


## Integración con backend
1) Copia `.env.example` a `.env` y ajusta `VITE_API_BASE`.
2) Asegúrate que tu API tenga CORS habilitado (ver snippet en la respuesta del asistente).
3) `npm install` y `npm run dev`.
